conda activate Groot_nlp

export FLASK_APP=NLPModule.py

python NLPModule.py