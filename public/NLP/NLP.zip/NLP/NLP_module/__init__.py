import time

import nltk
from flask import Flask
import socket

# import extensions

# all imports regarding other files of the application
from NLP_module.GlobalVar.Variables import queue

# import global variables
from NLP_module.GlobalVar.Variables import RUNNING, LOCAL, PORT
from NLP_module.NoRest.Controller.ControlCenter import start_main_control



def initialize_nlp_module(timeout_start=None):
    global RUNNING
    # if we want to use local host or the current ip-address
    global LOCAL

    nltk.download('wordnet')
    nltk.download('omw-1.4')
    nltk.download('punkt')

    # Create a TCP/IP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # get IP address
    ip_address = socket.gethostbyname(socket.gethostname()) if not LOCAL else 'localhost'

    # Bind the socket to the port 
    server_address = (ip_address, PORT)

    print('starting up on %s port %s' % server_address)
    sock.bind(server_address)

    sock.listen(1)

    conn = establish_connection(sock, 60)

    start_main_control(conn, establish_connection, sock)


# get a connection (NLP - Backend) object
def establish_connection(sock, timeout):
    timeout_start = time.time()
    conn = None

    # search for a connection for a specific time
    while time.time() < timeout_start + timeout:
        # Wait for a connection
        print('Waiting for a connection')
        conn, addr = sock.accept()

        # if a connection is found, exit
        if conn:
            print("Connection to Backend was established")
            break

    # if connection is still none throw an error
    if conn is None:
       raise Exception('No connection to Backend could be established (socket.accpet() => not working)')

    return conn

