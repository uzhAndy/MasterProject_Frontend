
class Speech2textResponse:
    def __init__(self, text: str, full_sentence: bool):
        self.text = text
        self.full_sentence = full_sentence

    def get_text(self) -> str:
        return self.text

    def is_full_sentence(self) -> bool:
        return self.full_sentence