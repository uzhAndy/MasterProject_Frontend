import websockets as ws
import base64
import asyncio
import pyaudio
import json
import os

from NLP_module.Service.Speech2TextStrategies.Speech2TextStrategy import Speech2TextStrategy
from NLP_module.Service.Speech2textResponse import Speech2textResponse


class AssemblyAI(Speech2TextStrategy):

    def __init__(self):
        # API token
        self.__api_key = ""

        # self.__transcript = Transcript()


    # parameters for the microphone and stream of the connection to the API
    SECONDS_PER_BUFFER = 0.2  # how long one buffer should take (in seconds; default 0.2)

    FORMAT = pyaudio.paInt16  # 16-bit int sampling
    CHANNELS = 1
    RATE = 16000  # sample rate, number of frames per second (leave unchanged!)
    FRAMES_PER_BUFFER = int(RATE * SECONDS_PER_BUFFER)  # number of frames that make up one buffer


    # RATE and FRAMES_PER_SECOND together determine how frequently the data is sent to and received by the API
    # increase FRAMES_PER_BUFFER number to increase the chunk size of data getting sent back and forth
    # -> increased chunk size gives more context so that the analysis phase can work with larger blocks of text
    # -> increased chunk size also increases the latency

    
    # the AssemblyAI endpoint we're going to hit
    URL = f"wss://api.assemblyai.com/v2/realtime/ws?sample_rate={RATE}"
    


    # ==================================================
    # helpers


    def set_api_key(self):
        """
        sets the API key
        """

        # read credentials.txt file if it exists
        if os.path.exists("NLP_module/credentials.txt"):
            with open('NLP_module/credentials.txt', "r") as f:
                api_key = f.readlines()[0]
        else:
            # create empty credentials.txt file if it doesn't exist
            with open('NLP_module/credentials.txt', "w") as f:
                f.write("")
            assert False, "credentials.txt file not found. We created one for you under NLP_module/credentials.txt. Please enter your AssemblyAI API key in the first line."

        self.__api_key = api_key


    def open_audio_stream(self):
        # pyaudio instance
        self.__p = pyaudio.PyAudio()

        # starts recording
        self.__stream = self.__p.open(
            format=self.FORMAT,
            channels=self.CHANNELS,
            rate=self.RATE,
            input=True,
            frames_per_buffer=self.FRAMES_PER_BUFFER
        )


    # # ==================================================
    # # AssemblyAI-specific functions


    async def send_receive(self, queue, listening_event) -> None:
        """
        asynchronously sends and receives data to and from the AssemblyAI API. It is stopped when the listening event is set to false (cleared) -> first the inner processes stop and then the outer process ends.

        heavily oriented on the following tutorial: https://www.assemblyai.com/blog/real-time-speech-recognition-with-python/
        """

        print(f"Connecting websocket to url {self.URL}")

        # setup connection with websocket of AssemblyAI API
        async with ws.connect(
            self.URL,
            extra_headers=(("Authorization", self.__api_key),),
            ping_interval=5,
            ping_timeout=20
        ) as _assemblyai_websocket_connection:

            # start connection
            await asyncio.sleep(0.1)
            print("Receiving SessionBeginns ...")
            session_begins = await _assemblyai_websocket_connection.recv()
            print(f"AssemblyAI SessionBegins: {session_begins}")
            print("Sending and receiving messages ...")

            async def send(self, listening_event):
                """function to get audio stream and send messages as encoded string to AssemblyAI API"""
                while listening_event.is_set():
                    try:
                        # get data from microphone
                        data = self.__stream.read(self.FRAMES_PER_BUFFER)
                        # encode data as base64
                        data = base64.b64encode(data).decode("utf-8")
                        json_data = json.dumps({"audio_data": str(data)})
                        # send data to AssemblyAI API
                        await _assemblyai_websocket_connection.send(json_data)

                    # handle errors
                    except ws.exceptions.ConnectionClosedError as e:
                        print("ERROR Assembly")
                        print(f"Connection closed: {e}")
                        assert e.code == 4008
                        break
                    except Exception as e:
                        assert False, "Not a websocket 4008 error"

                    await asyncio.sleep(0.01)

                print("Stopped sending data to AssemblyAI API")

                return True

            async def receive(queue, listening_event):
                """function to receive messages from AssemblyAI API and send them to the parent process via the queue"""
                while listening_event.is_set():
                    try:
                        # receive processed data/results from AssemblyAI API
                        result_str = await _assemblyai_websocket_connection.recv()
                        result = json.loads(result_str)

                        is_full_sentence = result["message_type"] == "FinalTranscript"
                        print(f"({result['message_type']}) {result['text']}")

                        # append text to queue
                        response = Speech2textResponse(result["text"], is_full_sentence)
                        queue.put(response)



                    # handle errors
                    except ws.exceptions.ConnectionClosedError as e:
                        print(f"Connection closed: {e}")
                        assert e.code == 4008
                        break
                    except Exception as e:
                        print(f"Error: {e}")
                        assert False, "Not a websocket 4008 error"

                print("Stopped receiving data from AssemblyAI API")


            # does the AssemblyAI timeout affect this?
            # start sending and receiving
            send_result, receive_result = await asyncio.gather(send(self, listening_event), receive(queue, listening_event))
            print(f"send result: {send_result}")
            print(f"receive result: {receive_result}")
        



    # ==================================================
    # interface functions

    @staticmethod
    def initialize_speech2text_process(queue, listening_event):

        # initialize AssemblyAI object
        assemblyai = AssemblyAI()

        # set a key
        assemblyai.set_api_key()

        # start connection to physical microphone
        assemblyai.open_audio_stream()

        asyncio.run(assemblyai.send_receive(queue, listening_event))










