import speech_recognition as sr
from NLP_module.Service.Speech2TextStrategies.Speech2TextStrategy import Speech2TextStrategy
from NLP_module.Service.Speech2textResponse import Speech2textResponse

class Google(Speech2TextStrategy):


    @staticmethod
    def initialize_speech2text_process(queue, listening_event):

        # callback function to handle speech recognition in the background and return the result
        def callback(recognizer, audio):
            # todo: send the recognized text to the bus for processing instead of printing it
            try:
                # convert speech to text using Google Speech Recognition API
                text = recognizer.recognize_google(audio)
                response = Speech2textResponse(text, True)
                queue.put(response)
            except sr.UnknownValueError:
                print("ERROR Google.py line 20")
                print("The API did not understand that.")
            except sr.RequestError as e:
                print("ERROR Google.py line 23")
                print(f"The API could not process your request: {e}")

        # instantiate the recognizer and microphone
        recognizer = sr.Recognizer()
        microphone = sr.Microphone()

        # adjust energy threshold for ambient noise
        # this threshold is later used to determine if phrases ended when listening for speech
        with microphone as source:
            print("Microphone is adjusting to background noise...")
            recognizer.adjust_for_ambient_noise(source, duration=1)

        # start listening for audio input in the background
        print("Mic is listening now...")
        stop_listening = recognizer.listen_in_background(microphone, callback)
        # `stop_listening` is now a function that, when called, stops background listening

        while listening_event.is_set():
            # this while loop is just to delay the stop function from being called until the listening_event is set to False
            pass

        # stop listening
        stop_listening(wait_for_stop=False)
        print("The mic stopped listening.")