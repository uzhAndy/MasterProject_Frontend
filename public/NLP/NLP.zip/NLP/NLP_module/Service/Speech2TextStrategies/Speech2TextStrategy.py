from abc import ABC, abstractmethod

class Speech2TextStrategy(ABC):

    @staticmethod
    @abstractmethod
    def initialize_speech2text_process(
        queue, # multiprocessing.Queue[Speech2textResponse], 
        listening_event # multiprocessing.Event
    ) -> None:
        """
        This function is called by the parent process to initialize the speech2text process.

        It should do the following:
        - initialize the connection to the system microphone and connect to the speech to text API of choice.
        - it should contain a while loop that runs until listening_event.is_set() is False. Inside that loop it should:
            - receive a message from the speech to text API and add them to the queue (expects Speech2textResponse objects). Note that a transcript gets created by the parent process only when a FULL sentence is received.
        """
        pass
