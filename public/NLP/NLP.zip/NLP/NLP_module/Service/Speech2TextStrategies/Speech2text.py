import time

from NLP_module.Service.Speech2textResponse import Speech2textResponse


class Speech2text:

    @staticmethod
    def initialize_speech2text_process(queue, listening_event):
        while listening_event.is_set():

            # example_sentence = "Can you tell me more about cluster risk?"
            full_sentence = True
            # queue.put(Speech2textResponse(example_sentence, full_sentence))
            #
            # time.sleep(2)
            #
            # example_sentence2 = "This sentence contains no pattern."
            # queue.put(Speech2textResponse(example_sentence2, full_sentence))
            #
            # time.sleep(2)
            #
            example_sentence2 = "The Inflation is currently very high"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "The cryptocurrency is currently very high"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "The bonds are also a viable option"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "The stocks are also a viable option"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "Have you thought about cluster risk"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "Have you thought about market risk"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "Have you thought about market capitalization"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "Have you thought about Hedging"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "Groot show me Stock"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            example_sentence2 = "Have you thought about Commodities"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "Have you thought about Maximum draw Down"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "Have you thought about Risk return profile"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "Have you thought about market risk"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)
            example_sentence2 = "Groot Show me stock"
            queue.put(Speech2textResponse(example_sentence2, full_sentence))
            time.sleep(1)

