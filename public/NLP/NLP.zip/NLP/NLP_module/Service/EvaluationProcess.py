import multiprocessing
import pickle
import re

import nltk


from NLP_module.GlobalVar.Variables import queue

from NLP_module.Service.Speech2TextStrategies.Speech2text import Speech2text
from NLP_module.Service.Speech2TextStrategies.Google import Google
from NLP_module.Service.Speech2TextStrategies.AssemblyAI import AssemblyAI

from NLP_module.Service.TranscriptClass import Transcript
from Levenshtein import distance as levenshtein_distance
from fuzzywuzzy import fuzz
from nltk.stem import WordNetLemmatizer


class EvaluationProcess():
    # default speech to text strategy
    __default_speech2text_strategy = Google
    __speech2text_strategy = __default_speech2text_strategy


    @staticmethod
    def set_speech2text_module(module: str) -> None:
        """
        module: string
        """
        if module == "AssemblyAI":
            EvaluationProcess.__speech2text_strategy = AssemblyAI
            print("AssemblyAI speech to text module selected")
        elif module == "Google":
            EvaluationProcess.__speech2text_strategy = Google
            print("Google speech to text module selected")
        elif module == "Mock_Script":
            EvaluationProcess.__speech2text_strategy = Speech2text
        else:
            EvaluationProcess.__speech2text_strategy = EvaluationProcess.__default_speech2text_strategy
            print("Invalid module name provided. Default speech to text module selected")
        

    @staticmethod
    def initialize_api_process(start_message, conn, listening_event, shared_dict):

        # get module name and all_terms from start_message, and set this module
        module_name = start_message["module"]
        all_terms = start_message["all_terms"]
        EvaluationProcess.set_speech2text_module(module_name)

        # start the speech2text transcription process
        # EvaluationProcess.__speech2text_strategy.initialize_speech2text_process,
        speech2text_process = multiprocessing.Process(
            target=EvaluationProcess.__speech2text_strategy.initialize_speech2text_process,
            name="Speech2text",
            args=(queue, listening_event)
        )

        # so it kills process automatically when parent process is killed
        speech2text_process.daemon = True
        speech2text_process.start()
        print("Speech2Text process was started")

        # start the listening event
        listening_event.set()
        print("Listening event was set -> microphone is on and listening")

        # create strategy pattern here
        EvaluationProcess.__evaluation(all_terms, conn, listening_event, shared_dict)

    @staticmethod
    def __evaluation(all_terms, conn, listening_event, shared_dict):
        """
        evaluates the transcriptions and returns the best matches.

        Continually empties the queue of the speech2text process and compares the results to the terms. If terms are found, then sends those to the backend, along the current partial transcript which then gets reset. If listening event is cleared (set to false), then the process ends and the last partial transcript is sent to the backend.

        all_terms: list of strings
        conn: multiprocessing.connection.Connection
        listening_event: multiprocessing.Event
        shared_dict: multiprocessing.sharedctypes.SharedMemory
        """

        print("Evaluation of results has started")
        transcript = Transcript()
        lemmatizer = WordNetLemmatizer()
        lemmatized_dict = EvaluationProcess.__create_lem_dict(all_terms, lemmatizer)

        # start the evaluation loop
        while listening_event.is_set():

            # check if something is in the queue
            if not queue.empty():
                # get object of queue
                speech2text_response = queue.get()

                # extract a full sentence from the response
                text = speech2text_response.get_text()
                if speech2text_response.is_full_sentence():
                    transcript.append_text(text)

                detected_patterns = EvaluationProcess.__find_patterns(text, all_terms, lemmatizer, lemmatized_dict)

                # send to backend
                if len(detected_patterns['active']) != 0 or len(detected_patterns['passive']) != 0:
                    print(f"Pattern found: {detected_patterns}")
                    try:

                        # add transcript to the message object and reset accumulated text in transcript class
                        temp = transcript.finalize_transcript(reset=True)
                        detected_patterns['metadata'] = temp['metadata']
                        detected_patterns['text'] = temp['text']

                        EvaluationProcess.send_to_backend(conn, detected_patterns, 'pattern')
                    except ConnectionResetError:
                        print("ERROR sending patterns")
                        conn.close()
                        break
        
        # when the listening_event is not set anymore, send the rest of the transcript to the backend
        # TODO try and catch might be removeable
        try:
            detected_patterns = EvaluationProcess.__find_patterns("", all_terms, lemmatizer, lemmatized_dict)
            temp = transcript.finalize_transcript(reset=True)
            detected_patterns['metadata'] = temp['metadata']
            detected_patterns['text'] = temp['text']
            EvaluationProcess.send_to_backend(conn, detected_patterns, 'pattern')
        except:
            print("Error in Evaluation Process line 126")
            print("Last message could not be sent due to lost connection")
            print("\n\n")

    @staticmethod
    def __find_patterns(text, all_terms, lemmatizer, lem_dict):
        # TODO more advanced algorithm
        # e.g.: "cryptocurrency" vs "crypto currency" <- right now this does not match (apart from my fix below), but it should -> maybe get rid of all spaces in text and values/keys
        result_list = {'active': [], 'passive': [], 'metadata': {}, "text": ""}

        if len(text) <= 0:
            return result_list

        # tokenize each word first
        word_list = nltk.word_tokenize(text)
        # lemmatize the words after all words were lowered and striped of " "
        lemmatized_output = ' '.join([lemmatizer.lemmatize(w.strip().lower()) for w in word_list])
        matched_pattern_index = {}

        for key, value in lem_dict.items():
            pattern_key = [m.start() for m in re.finditer(key, lemmatized_output)]
            pattern_syn = []

            for val in value:
                if val != "" and not key in result_list['passive']:
                    temp_index = [m.start() for m in re.finditer(val, lemmatized_output)]
                    if len(temp_index) > 0:
                        pattern_syn.extend(temp_index)
                        break

            if len(pattern_key) > 0 or len(pattern_syn) > 0:
                result_list['passive'].append(key)
                pattern_key.extend(pattern_syn)

                for ind in pattern_key:
                    matched_pattern_index[ind] = key

            arr = lemmatized_output.split()
            iterator = []
            for index, word in enumerate(key.split()):
                iterator.append(iter(arr[index:]))

            # check levenshtein distance as well
            # if any(levenshtein_distance(''.join(tuple), key) for tuple in zip(*iterator)) > 0.9 \
            #         and not key in result_list['passive']:
            #     result_list['passive'].append(key)
            for tuple in zip(*iterator):

                if fuzz.ratio(' '.join(tuple), key) >= 90 and not key in result_list['passive']:
                    index_levenshtein = [m.start() for m in re.finditer(''.join(tuple), lemmatized_output)]
                    result_list['passive'].append(key)

                    for ind in index_levenshtein:
                        matched_pattern_index[ind] = key

        # check for active mode
        for word in lemmatized_output.split():
            if fuzz.ratio(word, 'groot') >= 50 or 'oot' in word:
                index_groot = lemmatized_output.index(word)

                indexes_matches = list(matched_pattern_index.keys())

                if len(indexes_matches) > 0:
                    indexes_matches.sort()

                    key_active = list(filter(lambda match_ind: match_ind > index_groot, indexes_matches))
                    if len(key_active) > 0:
                        recognized_key = matched_pattern_index[list(key_active)[0]]
                        result_list['active'].append(recognized_key)

                        if recognized_key in result_list['passive']: result_list['passive'].remove(recognized_key)


        return result_list

    @staticmethod
    def __create_lem_dict(all_terms, lemmatizer):
        result = {}

        for key, values in all_terms.items():

            result[lemmatizer.lemmatize(key.strip().lower())] = \
                [lemmatizer.lemmatize(value.strip().lower()) for value in values]

        return result


    @staticmethod
    def send_to_backend(conn, data, type: str):
        try:
            message = {'type': type, 'data': data, 'ack': "ACK"}
            conn.send(EvaluationProcess.encode(message))
        except:
            print("Sending of :"+str(message)+" failed")

    @staticmethod
    def encode(obj):
        return pickle.dumps(obj)






