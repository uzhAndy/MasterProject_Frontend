from datetime import datetime

class Transcript:

    def __init__(self):
        self.__text = ""
        self.__start_datetime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        self.__end_datetime = None

    def append_text(self, text):
        self.__text += text + " "

    def finalize_transcript(self, reset=False):
        """if reset is True, then the transcript is reset to an empty string."""
        self.__end_datetime = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

        # get current text and reset it to an empty string
        current_text = self.__text
        if reset:
            self.__text = ""

        return {
            "metadata": {
                "transcription_start": self.__start_datetime,
                "transcription_end"  : self.__end_datetime
            },
            "text": current_text
        }


