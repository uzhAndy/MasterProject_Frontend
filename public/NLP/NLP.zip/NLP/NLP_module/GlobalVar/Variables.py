from multiprocessing import Queue


BASE_URL = 'http://localhost:5000'

# For communication between Speech2text Process and API_process
queue = Queue()

RECORDING = True
# if it should shut down the whole program (most outer loop)
RUNNING = True
# if the socket (server) should use the localhost ip for connection
LOCAL = True
# port for the socket
# -> should be larger than 1024, otherwise it will be blocked -> https://newbedev.com/python-bind-socket-error-errno-13-permission-denied
PORT = 2000  

