import multiprocessing
from datetime import datetime
import time

from NLP_module.GlobalVar import Variables
from NLP_module.Service.EvaluationProcess import EvaluationProcess

# stores the process to send things to the backend (API)
# additionally this process evaluates the text. TODO: isn't it the process spawned by this process (i.e. the APIProcess) that evaluates the text?

# this module is in the outermost/main scope/process, it spawns the APIProcess

# TODO: rename to MessageStrategy? how is this a strategy pattern?
class Strategy_Message:
    def __init__(self, data, conn, strategy=None):
        """take price and discount strategy"""
        self.strategy = strategy
        self.conn = conn
        self.data = data

    def execute_strategy(self):
        self.strategy(self)


class MessageActions:

    def __init__(self):
        print("created listening event")
        self.listening_event = multiprocessing.Event()
        self.API_PROCESS = multiprocessing.Process()
        self.API_PROCESS_shared_vars = multiprocessing.Manager().dict()

        # add empty structure to shared_vars dict
        start_time = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        self.API_PROCESS_shared_vars['transcript'] = {'metadata': {'transcription_start': start_time, 'transcription_end': start_time}, 'text': ''}


    def get_status(self):
        return (self.API_PROCESS and self.API_PROCESS.is_alive())


    def get_ack(self):
        return {"ack": "ACK", "data": "", "metadata":{"transcription_start": datetime.now()}}

    def do_nothing(self, strategy):
        pass

    def stop_immidiatly(self):
        print("Turning off microphone...")
        self.listening_event.clear()

        print("The Microphone was turned off.")
        print("Terminating speech2text process...")

        self.API_PROCESS.join()

        #raise ConnectionAbortedError('This is an error with the purpose to stop outer loop')


    def stop_mic(self, strategy):
        print("Turning off microphone...")
        self.listening_event.clear()

        print("The Microphone was turned off.")
        print("Terminating speech2text process...")

        self.API_PROCESS.join()


        strategy.conn.close()
        raise ConnectionAbortedError('This is an error with the purpose to stop outer loop')


    def start_mic(self, strategy):
        print("-------Turning on microphone...")
        # start a process to for transcription (if process is not already running and
        # if the keywords are given -> all terms is also the message type to start mic/transcribing
        if not self.API_PROCESS.is_alive():
            print(self.API_PROCESS_shared_vars)
            self.API_PROCESS = multiprocessing.Process(
                target=EvaluationProcess.initialize_api_process, 
                name="APIProcess",
                args=(strategy.data, strategy.conn, self.listening_event, self.API_PROCESS_shared_vars)
            )
            self.API_PROCESS.start()

            print(f"The Microphone was started: {self.API_PROCESS.is_alive()}")