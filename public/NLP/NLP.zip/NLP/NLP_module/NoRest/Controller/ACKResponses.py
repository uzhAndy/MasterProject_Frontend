# In here we define the immediate responses to different types of messages from the server
# the type of the message from the server is the key
# the value represents the response string
from NLP_module.NoRest.Controller.Strategy_Message import MessageActions

# TODO: give this class a more meaningful name, e.g. ACKResponsesSingleton?
# TODO: this is a free country and you can name this anything you want
class Singleton:
    __instance = None

    @staticmethod
    def getInstance():
        """ Static access method. """
        if Singleton.__instance == None:
            Singleton()

        return Singleton.__instance

    def __init__(self):
        """ Virtually private constructor. """
        self.start_mic_message_type = 'start_mic'
        self.stop_mic_message_type = 'stop_mic'
        self.status_message_type = 'status'

        # TODO: can be removed? -> theoretically yes
        self.messageAction = MessageActions()

        # mapping messages from server message types to responses/actions of the form
        # message: [
        #   response to server, 
        #   action to be executed in nlp backend
        # ]
        self.ACK = {
            self.start_mic_message_type: [
                self.messageAction.get_ack,
                self.messageAction.start_mic
            ],
            self.stop_mic_message_type: [
                self.messageAction.get_ack,
                self.messageAction.stop_mic
            ],
            self.status_message_type: [
                self.messageAction.get_status, 
                self.messageAction.do_nothing
            ]

        }

    def stop_recording(self):
        self.messageAction.stop_immidiatly()





