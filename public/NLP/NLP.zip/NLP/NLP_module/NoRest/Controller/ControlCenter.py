import pickle

from NLP_module.NoRest.Controller.ACKResponses import Singleton
from NLP_module.NoRest.Controller.Strategy_Message import Strategy_Message


def start_main_control(conn, establish_connection, sock):
    """starts and controls the main process (this process spawns the other processes)"""
    singleton = Singleton()
    # Running
    while True:
        try:
            # receive data (wait until data is received)
            strategy_obj, data = receive_data(conn, singleton)

            strategy_obj.execute_strategy()

        # completely destroyed by the client(backend side)
        # to be still able to switch the microphone back on
        # the function needs to search for new connections: It looks for a new connection in the next
        # 2 hours  todo: isn't the timeout set to 1h=3600s?
        except Exception as e:
            print("ERROR ControlCenter.py line 23")
            print(e)
            singleton.stop_recording()
            conn = establish_connection(sock, 3600)




# Problem might occur if backend sends data larger than 4096
# TODO: add docstring. does this method receive data from the backend and use Strategy_Message to send the response and execute the action? And Strategy_Message is only responsible for the mapping, while this method is responsible for the execution?
def receive_data(conn, singleton):
    # setting a default strategy
    strategy = Strategy_Message('undefined', conn, strategy=singleton.ACK[singleton.status_message_type][1])
    message_data = {}


    while True:

        # receive the data (receive data here)
        print("Waiting for Message from Backend")
        data_byte = conn.recv(4096)

        # decode the data and bring it into a dict form
        backend_message = decode(data_byte)
        print(f"NLP received the following message: {backend_message}")
        # data has the following form:
        # {
        #  type: 'string'
        #  data: {}
        #  }


        try:
            message_data = backend_message['data']
            message_type = backend_message['type']

            # getting the strategy, depending on the type of message
            strategy = Strategy_Message(
                message_data, 
                conn, 
                # get action to be executed in the nlp as strategy function
                strategy=singleton.ACK[message_type][1]
            )

            send_to_backend(
                conn, 
                message_type, 
                singleton.ACK[message_type][0]()['ack'], # get acknowledgement of the message to be sent back to the backend
                singleton.ACK[message_type][0]()['data'] # get data of the message to be sent back to the backend
            )
            break
        except Exception as e:
            print("ERROR Controle Center line 75")
            print(e)

            print("The message from the Backend had the wrong format")
            continue


    return strategy, message_data



def send_to_backend(conn, type: str, ack: str, data):
    message = {'type': type, 'ack': ack, 'data': data}
    conn.send(encode(message))

def encode(obj):
    return pickle.dumps(obj)

def decode(obj):
    return pickle.loads(obj)


