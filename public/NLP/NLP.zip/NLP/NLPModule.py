from NLP_module import initialize_nlp_module

initialize_nlp_module()
